export default {
    platform:"weChat"
}
