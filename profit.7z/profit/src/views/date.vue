<template>
    <div id="date">
        <div class="topTab">
            <img src="../assets/img/icon_back_yao@2x.png" alt="" @click="back" class="back">
            <span class="date-title" @click="showModal=!showModal">{{selected[0].valueStr}}{{selected[1].valueStr}}</span>
        </div>
        <div class="modal">
            <div class="mask" v-show="showModal"></div>
            <div class="modal-container" :class="{'showModal':showModal}">
                <div class="modal-content">
                    <mt-picker :itemHeight="52" valueKey="valueStr" :visibleItemCount="3" :slots="slots" @change="onValuesChange"></mt-picker>
                </div>
                <div class="modal-btn-group">
                    <div class="modal-btn cancel-btn"  @click="showModal=!showModal">取消</div>
                    <div class="modal-btn confirm-btn" @click="confirm">确定</div>
                </div>
            </div>
        </div>
        <div class="calendar">
            <div class="weekday-container">
                <div class="weekday">日</div>
                <div class="weekday">一</div>
                <div class="weekday">二</div>
                <div class="weekday">三</div>
                <div class="weekday">四</div>
                <div class="weekday">五</div>
                <div class="weekday">六</div>
            </div>
            <div class="date-container">
                <div class="wrap-date" v-for="item in dateArr">
                    <div class="ji" v-if="item.ji">吉</div>
                    <div class="date-content" :class="{'on':item.isCurrentDay}" @click="selectDate(item)">
                        <div class="date">{{item.cDay}}</div>
                        <div class="nl" :class="{'on':item.isTerm||item.ncWeek==='星期六'||item.ncWeek==='星期日'}">{{item.isTerm?item.Term:item.IDayCn}}</div>
                    </div>
                </div>
            </div>
        </div>
        <div style="padding-bottom: 0.3rem;background-color: rgb(243, 242, 242)">
            <div class="wrap-today">
                <div class="wrap-weather">
                    <div class="city">{{WeatherForecast.CityName}}&nbsp;&nbsp;<span style="font-size: 0.32rem;color:rgba(242,86,29,1); ">{{WeatherForecast.Temp}}℃</span></div>
                    <div class="weather">
                        现在{{WeatherForecast.Weather}}&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;湿度：{{WeatherForecast.Humidity}}
                        <br>
                        最高气温{{WeatherForecast.TempMax}}，今晚最低气温{{WeatherForecast.TempMin}}
                    </div>
                </div>
                <div class="wrap-activity">
                    <div class="activity">
                        <i class="left-i" style="background-color: rgba(157,232,235,1)">宜</i>
                        <div class="content">
                            <p class="li" v-for="item in yiList">{{item}}</p>
                        </div>
                    </div>
                    <div class="activity" style="margin-top: 0.24rem;">
                        <i class="left-i" style="background-color: rgba(249,168,168,1)">忌</i>
                        <div class="content">
                            <p class="li" v-for="item in jiList">{{item}}</p>
                        </div>
                    </div>
                </div>
                <div class="date-info">
                    {{currentDate.cYear}}年{{currentDate.monthStr}}月{{currentDate.dateStr}}日 {{currentDate.ncWeek}}
                    <br>
                    {{currentDate.gzYear}}年({{currentDate.Animal}}年) {{currentDate.gzMonth}}月 {{currentDate.gzDay}}日
                </div>
            </div>
        </div>
    </div>
</template>

<script>
    import calendar from "../utils/calendar"
    function addZero(n){
        return n<10?'0'+n:n;
    }
    export default {
        name: "date",
        data(){
            return{
                showModal:false,
                currentDate:{},
                slots: [
                    {
                        values: [],
                        className: 'slot1',
                        textAlign: 'right',
                        defaultIndex:1
                    }, {
                        values: [],
                        className: 'slot3',
                        textAlign: 'left',
                        defaultIndex:0
                    }
                ],
                values:[],
                selected:[],
                dateArr:[],
                dateInfo:{},
                yiList:{},
                jiList:{},
                WeatherForecast:{}
            }
        },
        methods:{
            back:function () {
                this.platform.back();
            },
            onValuesChange(picker, values) {
                this.values=values;
            },
            confirm:function () {
                this.selected=JSON.parse(JSON.stringify(this.values));
                this.setMonth(this.selected[0].year,this.selected[1].month+1);
                this.showModal=!this.showModal;
            },
            initDate:function () {
                this.setDate();
                let yearArr=[];
                for(let i=0;i<5;i++){
                    yearArr.push({
                        year:this.currentDate.cYear-1+i,
                        valueStr:this.currentDate.cYear-1+i+"年"
                    });
                }

                let monthArr=[];
                let monthDefaultIndex=0;
                for(let m=0;m<12;m++){
                    monthArr.push({
                        month:m,
                        valueStr:m+1+"月"
                    });
                    if(this.currentDate.cMonth===m+1){
                        monthDefaultIndex=m;
                    }
                }

                this.slots[0].values=yearArr;
                this.slots[1].values=monthArr;
                this.slots[1].defaultIndex=monthDefaultIndex;
                this.selected.push(this.slots[0].values[1]);
                this.selected.push(this.slots[1].values[this.slots[1].defaultIndex])
                this.setMonth();
            },
            setMonth:function (year,month) {
                let dateArr=[];
                let y=year||this.currentDate.cYear;
                let mon=month||this.currentDate.cMonth;
                let firstDay=new Date(y,mon-1,1);
                let lastDay=new Date(y,mon,0);
                let m=0;
                for(let i=0;i<firstDay.getDay()+lastDay.getDate();i++){
                    if(i<firstDay.getDay()){
                        dateArr.push({})
                    }else{
                        let dateObj=calendar.solar2lunar(y,mon,++m);
                        if(dateObj.cYear===this.currentDate.cYear&&dateObj.cMonth===this.currentDate.cMonth&&dateObj.cDay===this.currentDate.cDay){
                            dateObj.isCurrentDay=true;
                        }else{
                            dateObj.isCurrentDay=false;
                        }
                        dateArr.push(dateObj)
                    }
                }
                this.dateArr=dateArr;
                this.getMonthInfo();
            },
            setDate:function (date) {
                let d=new Date();
                if(date){
                    d=new Date(date);
                }
                this.currentDate=calendar.solar2lunar(d.getFullYear(),d.getMonth()+1,d.getDate());
                this.currentDate.monthStr=addZero(this.currentDate.cMonth);
                this.currentDate.dateStr=addZero(this.currentDate.cDay);
                this.getDateInfo();
            },
            selectDate:function (item) {
                if(item.cYear){
                    this.setDate(new Date(item.cYear,item.cMonth-1,item.cDay));
                    this.dateArr.forEach(val=>{
                        if(val.cYear===this.currentDate.cYear&&val.cMonth===this.currentDate.cMonth&&val.cDay===this.currentDate.cDay){
                            val.isCurrentDay=true;
                        }else{
                            val.isCurrentDay=false;
                        }
                    })
                }
            },
            getDateInfo:function () {
                this.$get("/api/PerpetualCalendar/GetCalendarInformation",{
                    params:{
                        date:this.currentDate.cYear+"-"+this.currentDate.cMonth+"-"+this.currentDate.cDay
                    }
                }).then(res=>{
                    if(res.ReturnCode === 0){
                        this.dateInfo=res.ReturnObject;
                        this.yiList=this.dateInfo.PerpetualCalendar.Suit.split(".");
                        this.jiList=this.dateInfo.PerpetualCalendar.Avoid.split(".");
                        this.WeatherForecast=res.ReturnObject.WeatherForecast||this.WeatherForecast;
                    }else{
                        this.$toast(res.Message)
                    }
                })
            },
            getMonthInfo:function () {
                this.$get("/api/PerpetualCalendar/GetMonthAvoidDay",{
                    params:{
                        date:this.selected[0].year+"-"+(this.selected[1].month+1)
                    }
                }).then(res=>{
                    if(res.ReturnCode === 0){
                        this.dateArr.forEach(val=>{
                            res.ReturnObject.forEach(val2=>{
                                if(val.cDay&&val.cDay===val2){
                                    this.$set(val,'ji',true)
                                }
                            })
                        })
                    }else{
                        this.$toast(res.Message)
                    }
                })
            }
        },
        created() {
            this.initDate();
        }
    }
</script>
<style>
    html,body,#app{
        height: 100%;
        overflow-y: auto;
    }
    #date .slot1,#date .slot2,#date .slot3{
        height: 156px;
        width: 100%;
    }
    #date .picker-center-highlight{
        display: none;
    }
    #date .picker-item{
        text-align: center;
        border: 0;
        color: #CECECE;
        font-size: 11px;
        font-family: GothamBookRegular;
    }
    #date .picker-item.picker-selected{
        font-size: 14px;
        color: #F2561D;
    }
</style>
<style scoped>
    .ji{
        position: absolute;
        left: 0;
        top: 0;
        width:0.26rem;
        height:0.26rem;
        border:1px solid rgba(242,86,29,1);
        border-radius:50%;
        text-align: center;
        line-height: 0.26rem;
        font-size:0.18rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(242,86,29,1);
        background-color: #fff;
    }
    .date-info{
        font-size:0.24rem;
        font-family:GothamBookRegular;
        font-weight:400;
        color:rgba(138,138,138,1);
        line-height: 0.4rem;
        text-align: center;
        padding-bottom: 0.3rem;
    }
    .content .li{
        font-size:0.28rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(43,43,43,1);
        line-height: 0.4rem;
        margin-left: 0.3rem;
        float: left;
    }
    .content{
        flex: 1;
        overflow: hidden;
    }
    .activity .left-i{
        display: block;
        width: 0.4rem;
        height: 0.4rem;
        border-radius: 50%;
        overflow: hidden;
        font-size:0.24rem;
        font-family:PingFang-SC-Medium;
        font-weight:500;
        color:rgba(255,255,255,1);
        line-height: 0.4rem;
        text-align: center;
        font-style: normal;
    }
    .activity{
        display: flex;
    }
    .wrap-activity{
        padding: 0.4rem 0.6rem;
        box-sizing: border-box;
        width: 100%;
    }
    .weather{
        text-align: center;
        font-size:0.26rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(153,153,153,1);
        line-height: 0.46rem;
        width: 5.9rem;
        margin: 0.2rem auto 0;
        padding-bottom: 0.2rem;
        border-bottom: 1px solid rgba(240,240,240,1);
    }
    .city{
        text-align: center;
        font-size:0.32rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(43,43,43,1);
        line-height: 0.32rem;
    }
    .wrap-weather{
        padding: 0.4rem 0 0;
    }
    .wrap-today{
        width: 7.1rem;
        background-color: #fff;
        margin: 0.2rem 0.2rem 0;
        border-radius: 0.1rem;
    }
    #date{
        background-color: rgb(243, 242, 242);
        height: 100%;
    }
    .nl.on{
        color:rgba(242, 86, 29, 1);
    }
    .nl{
        font-size:0.24rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(206,206,206,1);
        line-height: 0.42rem;
    }
    .date{
        font-size:0.28rem;
        font-family:GothamBookRegular;
        font-weight:400;
        color:rgba(43,43,43,1);
        line-height: 0.3rem;
    }
    .calendar{
        background-color: #fff;
        padding:1.28rem 0.2rem 0.3rem;
    }
    .date-content.on{
        border-radius: 0.1rem;
        background-color:rgba(242, 86, 29, 1);
    }
    .date-content.on .date,.date-content.on .nl{
        color: #fff;
    }
    .date-content{
        width: 0.72rem;
        height: 0.72rem;
        margin: 0 auto;
        padding-top: 0.1rem;
    }
    .date-container{
        display: flex;
        width: 100%;
        flex-wrap: wrap;
    }
    .wrap-date{
        margin-top: 0.4rem;
        width: 14.28%;
        text-align: center;
        position: relative;
    }
    .weekday{
        flex: 1;
        font-size:0.22rem;
        font-family:PingFang-SC-Medium;
        font-weight:500;
        color:rgba(27,27,27,1);
        text-align: center;
    }
    .weekday-container{
        display: flex;
    }
    .modal-content{
        height: 156px;
    }
    .modal-btn-group{
        height: 40px;
        line-height: 40px;
        border-top: 1px solid rgba(240,240,240,1);
    }
    .confirm-btn{
        color:rgba(43,43,43,1);
    }
    .cancel-btn{
        color:rgba(138,138,138,1);
    }
    .modal-btn{
        width: 50%;
        float: left;
        text-align: center;
        font-size:0.28rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
    }
    .modal-container{
        position: fixed;
        left: 0;
        top: -196px;
        width: 100%;
        height:196px;
        background-color: #fff;
        overflow: hidden;
        transition: all 0.3s;
        z-index: 6;
    }
    .showModal{
        top:0.88rem
    }
    .mask{
        position: fixed;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
        z-index: 5;
        background-color: rgba(0,0,0,0.3);
    }
    .topTab{
        position: fixed;
        top:0;
        left: 0;
        height:0.88rem;
        line-height: 0.88rem;
        background:rgba(255,255,255,1);
        text-align: center;
        width: 100%;
        z-index: 10;
        border-bottom: 1px solid rgba(240,240,240,1);
    }
    .back{
        position: absolute;
        left: 0.2rem;
        top: 0.26rem;
        width: 0.36rem;
        height: 0.36rem;
    }
    .date-title{
        display: inline-block;
        font-size:0.32rem;
        font-family:PingFang-SC-Light;
        font-weight:bold;
        color:rgba(51,51,51,1);
        position: relative;
    }
    .date-title:after{
        content: '';
        width: 0;
        height: 0;
        border-left: 0.1rem solid transparent;
        border-right: 0.1rem solid transparent;
        border-top: 0.1rem solid #474747;
        margin-left: 0.1rem;
        position: absolute;
        right: -0.3rem;
        top: 0.38rem;
    }
</style>
