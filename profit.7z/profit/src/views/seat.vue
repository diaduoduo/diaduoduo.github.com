<template>
    <div id="seat">
        <top-tab title="预览"  @back="back" v-show="!hideTop">
            <div class="right-send" @click="share">发送</div>
        </top-tab>
        <div class="container" :class="{'share':hideTop}">
            <div class="wrap-top">
                <p class="title">{{name}}的婚礼</p>
                <div class="wrap-search">
                    <div class="placeholder" v-show="!keyword">
                        <img src="../assets/img/icon-search_city@2x.png" class="search-icon" alt="">
                        输入宾客名字，快速查座
                    </div>
                    <input type="text" class="search" v-model="keyword" @input="search">
                </div>
            </div>
            <div class="list">
                <div class="li" v-for="item in list2" :key="item.ID">
                    <div class="li-title">{{item.TableFullName}}</div>
                    <div class="seat-list">
                        <div class="seat-li" v-for="item2 in item.MarryGuests" :class="{'on':item2.IsKeyWord}" :key="item2.ID">{{item2.Name}}</div>
                    </div>
                </div>
                <p class="tips" v-show="list2.length===0&&hasGetInfo">未搜索到相关座位信息</p>
            </div>
        </div>
    </div>
</template>

<script>
    export default {
        name: "seat",
        data(){
            return{
                keyword:'',
                list:[],
                list2:[],
                hasGetInfo:false,
                hideTop:false,
                name:''
            }
        },
        methods:{
            share:function(){
                let url=window.location.href;
                if(Object.keys(this.$route.query).length>0){
                    url+="&type=share"
                }else{
                    url+="?type=share"
                }
                this.platform.share({
                    title:this.name+"的婚礼",
                    content:"这是你的座位安排，欢迎您的到来。",
                    url:url
                });
            },
            back:function(){
                let page=this.$route.query.page;
                if(!page){
                    this.platform.back();
                }
            },
            search:function(){
                let list=JSON.parse(JSON.stringify(this.list));
                let arr=[];
                if(this.keyword){
                    list.forEach(val=>{
                        let flag=false;
                        val.MarryGuests.forEach(val2=>{
                            if(val2.Name.indexOf(this.keyword.trim())!==-1){
                                flag=true;
                                val2.IsKeyWord=true;
                            }else{
                                val2.IsKeyWord=false;
                            }
                        });
                        if(flag){
                            arr.push(val);
                        }
                    });
                }else{
                    arr=list;
                }
                this.list2=arr;
            },
            getSeats:function () {
                this.$get("/api/MarrySeat/GetH5UserSeatGuests",{
                    params:{
                        keyWord:''
                    }
                }).then(res=>{
                    if(res.ReturnCode === 0){
                        this.list=res.ReturnObject.SeatGuestVMs;
                        this.name=res.ReturnObject.UserName;
                        this.search();
                        this.hasGetInfo=true;
                    }else{
                        this.$toast(res.Message)
                    }
                })
            },
        },
        created() {
            if(this.$route.query.keyword){
                this.keyword=this.$route.query.keyword;
            }
            if(this.$route.query.type&&this.$route.query.type==="share"){
                this.hideTop=true;
            }
            this.getSeats();
        }
    }
</script>

<style scoped>
    .share{
        padding-top: 0;
    }
    .tips{
        font-size:0.3rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(43,43,43,1);
        text-align: center;
        margin-top: 1rem;
    }
    .seat-li.on{
        color:rgba(242, 86, 29, 1) ;
    }
    .seat-li{
        margin-top: 0.2rem;
        margin-right: 0.3rem;
        font-size:0.28rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(138,138,138,1);
        float: left;
    }
    .seat-list{
        overflow: hidden;
    }
    .li-title{
        text-align: center;
        font-size:0.32rem;
        font-family:PingFang-SC-Medium;
        font-weight:500;
        color:rgba(43,43,43,1);
        line-height: 0.4rem;
    }
    .li{
        border-bottom: 1px solid rgba(240,240,240,1);
        padding: 0.47rem 0 0.4rem;
    }
    .list{
        padding: 0 0.3rem;
    }
    .search-icon{
        width: 0.26rem;
        height: 0.26rem;
        vertical-align: middle;
    }
    .placeholder{
        position: absolute;
        left:0;
        top:0;
        width: 100%;
        height: 100%;
        text-align: center;
        font-size:0.24rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(206,206,206,1);
        line-height: 0.56rem;
    }
    .search{
        display: block;
        width: 100%;
        height: 100%;
        border:0;
        border-radius:0.28rem;
        outline: 0;
        padding: 0 0.3rem;
        text-align: center;
        font-size:0.24rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        box-sizing: border-box;
        position: relative;
        z-index: 1;
        background: rgba(0,0,0,0);
    }
    .wrap-search{
        width: 5rem;
        height: 0.56rem;
        margin: 0.5rem auto;
        position: relative;
        border:1px solid rgba(206,206,206,1);
        border-radius:0.28rem;
        overflow: hidden;
        background: #fff;
    }
    .title{
        font-size:0.38rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(43,43,43,1);
        line-height: 0.5rem;
        padding-top: 1.7rem;
        text-align: center;
    }
    .wrap-top{
        width: 100%;
        height: 3.94rem;
        background: url("../assets/img/photo_bj@2x.png") no-repeat;
        background-size: cover;
        position: relative;
    }
    .right-send{
        position: absolute;
        right: 0.3rem;
        top:0;
        line-height: 0.88rem;
        font-size:0.3rem;
        font-family:PingFang-SC-Regular;
        font-weight:400;
        color:rgba(242,86,29,1);
    }
</style>
