module.exports={
    publicPath:process.env.baseUrl
}
