
store 产品
order 订单
user 会员
wechat 微信用户
record 数据
finance 财务
ump 营销
system 设置
article 内容
server 升级服务器版