<?php
return [
    'cache_dir' => 'uploads/qrcode', //本地缓存地址
    'background'=> 'static/qrcode/background.png' //背景图
];