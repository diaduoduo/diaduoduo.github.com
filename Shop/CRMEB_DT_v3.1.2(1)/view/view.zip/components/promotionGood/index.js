var app = getApp();
Component({
  properties: {
    benefit: {
      type: Object,
      value: [],
    }
  },
  data: {

  },
  ready: function () {

  },
  attached: function () {

  },
  methods: {

  }
})