// module.exports={
//     publicPath:process.env.baseUrl,
//     // 代理
//     devServer: {
//        // port: 8001,
//         proxy: {
//             '/apiPhp': {
//                 target: 'http://10.0.100.164',
//                 ws: true,
//                 changeOrigin: true,
//                 pathRewrite: {
//                     '^/apiPhp': ''
//                 }
//             },
//         },
//     },
// }

module.exports = {
        // runtimeCompiler: true,
        publicPath: process.env.baseUrl,
        devServer: { 
            // open: process.platform === 'darwin', 
            // host: 'localhost', 
            // port: 8071, 
            // open: true, //配置自动启动浏览器 
            proxy: {
                    '/apiPhp':
                     {
                        target: 'http://10.0.100.164/apiPhp/',
            //对应自己的接口 
            changeOrigin: true,
             ws: true, 
             pathRewrite: 
             {
                 '^/apiPhp': ''
             }
            } 
        } 
    },
 }
 