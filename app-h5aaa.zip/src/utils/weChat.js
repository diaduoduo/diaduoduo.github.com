export default {
    platform:"weChat",
    createOrder:function () {

    },
    loadStores:function(){

    },
    chat:function () {
        window.location.href="./cs.html";
    }
}
